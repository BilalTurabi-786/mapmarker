<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
  <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT  &copy; 2019<a class="text-bold-800 grey darken-2" href="javascript:void(0)" target="_blank">HNH Tech Solutions,</a>All rights Reserved</span><span class="float-md-right d-none d-md-block"></span>
    <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="fa fa-arrow-up"></i></button>
  </p>
</footer>
<!-- END: Footer--><?php /**PATH C:\xampp\htdocs\job\Map\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>